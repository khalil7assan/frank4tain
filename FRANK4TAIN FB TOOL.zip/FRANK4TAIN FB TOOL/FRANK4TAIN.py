#!usr/bin/python
#decode: UTF-8
#coded: HeCToR ^ Khalil Hassan ^ :")
import requests, json

logo = """
 _____ ____      _    _   _ _  ___  _ _____  _    ___ _   _ 
|  ___|  _ \    / \  | \ | | |/ / || |_   _|/ \  |_ _| \ | |
| |_  | |_) |  / _ \ |  \| | ' /| || |_| | / _ \  | ||  \| |
|  _| |  _ <  / ___ \| |\  | . \|__   _| |/ ___ \ | || |\  |
|_|   |_| \_\/_/   \_\_| \_|_|\_\  |_| |_/_/   \_\___|_| \_| \n
	FRANK4TAIN FACEBOOK TOOL => Contain Much Things !! :")\n
		Coded by HeCToR. => Khalil Hassan => FB@Khalil7assan\n
				https://www.facebook.com/khalil7assan\n
"""

print(logo)
print('^^ Pages Tools ^^')
print('1.Rating Pages With Access Token')
print('2.Like Pages With Access Token')
print('^^ Accounts Tools ^^')
print('3.Follow Accounts With Access Token')
print('4.Likes Posts With Access Token')
print('5.Share Posts With Access Token')
print('6.Poking Acc With Access Token')
print('7.Friend Request With Access Token')
print('8.Share Posts With Page Token')
print('>>>>>>>>>>>>>>>>>>>>|<<<<<<<<<<<<<<<<<<<<')

ask = input('Please Chosse Tool Number >> ')

# Rating Pages :")
if (int(ask) == 1):
	p_user = input('Enter Page ID >> ')
	ratings_number = input('Enter Rating Number >> ')
	access_token = input('Enter Access Tokens File >> ')
	opener = open(access_token, 'r').readlines()
	for at in opener:
		token = at.strip()
		link = 'https://graph.facebook.com/' +p_user+ '/ratings?Name=hector&rating=' +ratings_number+ '&access_token=' +token+ '&method=post'
		https = requests.post(link)
		indata = https.content
		ok = json.loads.(indata.decode("utf-8"))
		if "true" in ok:
			print('DONE SUCCESSFUL !!')
		else
			print('THERE IS FUCKEN ERROR !!')
# Like Pages :")
elif (int(ask) == 2):
	p_user = input('Enter Page ID >> ')
	access_token = input('Enter Access Tokens File >> ')
	opener = open(access_token, 'r').readlines()
	for at in opener:
	token = at.strip()
	link = 'https://graph.facebook.com/' +p_user+ '/likes?access_token=' +token+ '&method=post'
	https = requests.post(link)
	indata = https.content
	ok = json.loads.(indata.decode("UTF-8"))
	if "true" in ok:
		print('DONE SUCCESSFUL !!')
	else
		print('THERE IS FUCKEN ERROR !!')
# Following Accounts :")
elif (int(ask) == 3):
	acc_id = input('Enter Your Account ID >> ')
	access_token = input('Enter Access Tokens File >> ')
	opener = open(access_token, 'r').readlines()
	for at in opener:
		token = at.strip()
		link = 'https://graph.facebook.com/' +acc_id+ '/subscribers?access_token=' +token+ '&method=post'
		https = requests.post(link)
		indata = https.content
		ok = json.loads.(indata.decode("UTF-8"))
		if "true" in ok:
			print('DONE SUCCESSFUL !!')
		else
			print('THERE IS FUCKEN ERROR !!')
# Liking Posts :")
elif (int(ask) == 4):
	post_id = input('Enter Your Post ID >> ')
	access_token = input('Enter Access Tokens File >> ')
	opener = open(access_token, 'r').readlines()
	for at in opener:
		token = at.strip()
		link = 'https://graph.facebook.com/' +post_id+ '/likes?access_token=' +token+ '&method=post'
		https = requests.post(link)
		indata = https.content
		ok = json.loads.(indata.decode("UTF-8"))
		if "true" in ok:
			print('DONE SUCCESSFUL !!')
		else
			print('THERE IS FUCKEN ERROR !!')
# Sharing Posts With Acc Token :")
elif (int(ask) == 5):
	post_id = input('Enter Your Post ID >> ')
	access_token = input('Enter Access Tokens File >> ')
	opener = open(access_token, 'r').readlines()
	for at in opener:
		token = at.strip()
		link = 'https://graph.facebook.com/' +post_id+ '/sharedposts?access_token=' +token+ '&method=post'
		https = requests.post(link)
		indata = https.content
		ok = json.loads.(indata.decode("UTF-8"))
		if "true" in ok:
			print('DONE SUCCESSFUL !!')
		else
			print('THERE IS FUCKEN ERROR !!')
# Poking Accounts :")
elif (int(ask) == 6):
	acc_id = input('Enter Your Account ID >> ')
	access_token = input('Enter Access Tokens File >> ')
	opener = open(access_token, 'r').readlines()
	for at in opener:
		token = at.strip()
		link = 'https://graph.facebook.com/' +acc_id+ '/pokes?access_token=' +token+ '&method=post'
		https = requests.post(link)
		indata = https.content
		ok = json.loads.(indata.decode("UTF-8"))
		if "true" in ok:
			print('DONE SUCCESSFUL !!')
		else
			print('THERE IS FUCKEN ERROR !!')
# Friend Requests :")
elif (int(ask) == 7):
	acc_id = input('Enter Your Account ID >> ')
	access_token = input('Enter Access Tokens File >> ')
	opener = open(access_token, 'r').readlines()
	for at in opener:
		token = at.strip()
		link = 'https://graph.facebook.com/' +acc_id+ '/friendrequests?access_token=' +token+ '&method=post'
		https = requests.post(link)
		indata = https.content
		ok = json.loads.(indata.decode("UTF-8"))
		if "true" in ok:
			print('DONE SUCCESSFUL !!')
		else
			print('THERE IS FUCKEN ERROR !!')
# Sharing Posts With Page Token :")
elif (int(ask) == 8)
	post_id = input('Enter Your Post ID >> ')
	page_token = input('Enter Access Tokens File >> ')
	opener = open(page_token, 'r').readlines()
	for at in opener:
		token = at.strip()
		link = 'https://graph.facebook.com/' +post_id+ '/sharedposts?access_token=' +token+ '&method=post'
		https = requests.post(link)
		indata = https.content
		ok = json.loads.(indata.decode("UTF-8"))
		if "true" in ok:
			print('DONE SUCCESSFUL !!')
		else
			print('THERE IS FUCKEN ERROR !!')
